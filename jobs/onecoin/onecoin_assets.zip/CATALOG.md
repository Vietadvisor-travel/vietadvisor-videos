# Image catalogue: onecoin (472 images)

Use ONLY these ids in the storyboard (mid=, bg=, fg=, @id in build, img() in custom scenes).

| id | role | what it shows | licence / credit | AI |
|---|---|---|---|---|
| `onecoin_clip_airport__000` | clip | — | CC BY 3.0 · Wikimedia Commons: Frankfurt Airport timelapse |  |
| `onecoin_clip_airport__001` | clip | — | CC BY 3.0 · Wikimedia Commons: Frankfurt Airport timelapse |  |
| `onecoin_clip_airport__002` | clip | — | CC BY 3.0 · Wikimedia Commons: Frankfurt Airport timelapse |  |
| `onecoin_clip_airport__003` | clip | — | CC BY 3.0 · Wikimedia Commons: Frankfurt Airport timelapse |  |
| `onecoin_clip_airport__004` | clip | — | CC BY 3.0 · Wikimedia Commons: Frankfurt Airport timelapse |  |
| `onecoin_clip_airport__005` | clip | — | CC BY 3.0 · Wikimedia Commons: Frankfurt Airport timelapse |  |
| `onecoin_clip_airport__006` | clip | — | CC BY 3.0 · Wikimedia Commons: Frankfurt Airport timelapse |  |
| `onecoin_clip_airport__007` | clip | — | CC BY 3.0 · Wikimedia Commons: Frankfurt Airport timelapse |  |
| `onecoin_clip_airport__008` | clip | — | CC BY 3.0 · Wikimedia Commons: Frankfurt Airport timelapse |  |
| `onecoin_clip_airport__009` | clip | — | CC BY 3.0 · Wikimedia Commons: Frankfurt Airport timelapse |  |
| `onecoin_clip_airport__010` | clip | — | CC BY 3.0 · Wikimedia Commons: Frankfurt Airport timelapse |  |
| `onecoin_clip_airport__011` | clip | — | CC BY 3.0 · Wikimedia Commons: Frankfurt Airport timelapse |  |
| `onecoin_clip_airport__012` | clip | — | CC BY 3.0 · Wikimedia Commons: Frankfurt Airport timelapse |  |
| `onecoin_clip_airport__013` | clip | — | CC BY 3.0 · Wikimedia Commons: Frankfurt Airport timelapse |  |
| `onecoin_clip_airport__014` | clip | — | CC BY 3.0 · Wikimedia Commons: Frankfurt Airport timelapse |  |
| `onecoin_clip_airport__015` | clip | — | CC BY 3.0 · Wikimedia Commons: Frankfurt Airport timelapse |  |
| `onecoin_clip_airport__016` | clip | — | CC BY 3.0 · Wikimedia Commons: Frankfurt Airport timelapse |  |
| `onecoin_clip_airport__017` | clip | — | CC BY 3.0 · Wikimedia Commons: Frankfurt Airport timelapse |  |
| `onecoin_clip_airport__018` | clip | — | CC BY 3.0 · Wikimedia Commons: Frankfurt Airport timelapse |  |
| `onecoin_clip_airport__019` | clip | — | CC BY 3.0 · Wikimedia Commons: Frankfurt Airport timelapse |  |
| `onecoin_clip_airport__020` | clip | — | CC BY 3.0 · Wikimedia Commons: Frankfurt Airport timelapse |  |
| `onecoin_clip_airport__021` | clip | — | CC BY 3.0 · Wikimedia Commons: Frankfurt Airport timelapse |  |
| `onecoin_clip_airport__022` | clip | — | CC BY 3.0 · Wikimedia Commons: Frankfurt Airport timelapse |  |
| `onecoin_clip_airport__023` | clip | — | CC BY 3.0 · Wikimedia Commons: Frankfurt Airport timelapse |  |
| `onecoin_clip_airport__024` | clip | — | CC BY 3.0 · Wikimedia Commons: Frankfurt Airport timelapse |  |
| `onecoin_clip_airport__025` | clip | — | CC BY 3.0 · Wikimedia Commons: Frankfurt Airport timelapse |  |
| `onecoin_clip_airport__026` | clip | — | CC BY 3.0 · Wikimedia Commons: Frankfurt Airport timelapse |  |
| `onecoin_clip_airport__027` | clip | — | CC BY 3.0 · Wikimedia Commons: Frankfurt Airport timelapse |  |
| `onecoin_clip_airport__028` | clip | — | CC BY 3.0 · Wikimedia Commons: Frankfurt Airport timelapse |  |
| `onecoin_clip_airport__029` | clip | — | CC BY 3.0 · Wikimedia Commons: Frankfurt Airport timelapse |  |
| `onecoin_clip_airport__030` | clip | — | CC BY 3.0 · Wikimedia Commons: Frankfurt Airport timelapse |  |
| `onecoin_clip_airport__031` | clip | — | CC BY 3.0 · Wikimedia Commons: Frankfurt Airport timelapse |  |
| `onecoin_clip_airport__032` | clip | — | CC BY 3.0 · Wikimedia Commons: Frankfurt Airport timelapse |  |
| `onecoin_clip_airport__033` | clip | — | CC BY 3.0 · Wikimedia Commons: Frankfurt Airport timelapse |  |
| `onecoin_clip_airport__034` | clip | — | CC BY 3.0 · Wikimedia Commons: Frankfurt Airport timelapse |  |
| `onecoin_clip_airport__035` | clip | — | CC BY 3.0 · Wikimedia Commons: Frankfurt Airport timelapse |  |
| `onecoin_clip_athens__000` | clip | — | CC BY 3.0 · Wikimedia Commons: Athens city tour |  |
| `onecoin_clip_athens__001` | clip | — | CC BY 3.0 · Wikimedia Commons: Athens city tour |  |
| `onecoin_clip_athens__002` | clip | — | CC BY 3.0 · Wikimedia Commons: Athens city tour |  |
| `onecoin_clip_athens__003` | clip | — | CC BY 3.0 · Wikimedia Commons: Athens city tour |  |
| `onecoin_clip_athens__004` | clip | — | CC BY 3.0 · Wikimedia Commons: Athens city tour |  |
| `onecoin_clip_athens__005` | clip | — | CC BY 3.0 · Wikimedia Commons: Athens city tour |  |
| `onecoin_clip_athens__006` | clip | — | CC BY 3.0 · Wikimedia Commons: Athens city tour |  |
| `onecoin_clip_athens__007` | clip | — | CC BY 3.0 · Wikimedia Commons: Athens city tour |  |
| `onecoin_clip_athens__008` | clip | — | CC BY 3.0 · Wikimedia Commons: Athens city tour |  |
| `onecoin_clip_athens__009` | clip | — | CC BY 3.0 · Wikimedia Commons: Athens city tour |  |
| `onecoin_clip_athens__010` | clip | — | CC BY 3.0 · Wikimedia Commons: Athens city tour |  |
| `onecoin_clip_athens__011` | clip | — | CC BY 3.0 · Wikimedia Commons: Athens city tour |  |
| `onecoin_clip_athens__012` | clip | — | CC BY 3.0 · Wikimedia Commons: Athens city tour |  |
| `onecoin_clip_athens__013` | clip | — | CC BY 3.0 · Wikimedia Commons: Athens city tour |  |
| `onecoin_clip_athens__014` | clip | — | CC BY 3.0 · Wikimedia Commons: Athens city tour |  |
| `onecoin_clip_athens__015` | clip | — | CC BY 3.0 · Wikimedia Commons: Athens city tour |  |
| `onecoin_clip_athens__016` | clip | — | CC BY 3.0 · Wikimedia Commons: Athens city tour |  |
| `onecoin_clip_athens__017` | clip | — | CC BY 3.0 · Wikimedia Commons: Athens city tour |  |
| `onecoin_clip_athens__018` | clip | — | CC BY 3.0 · Wikimedia Commons: Athens city tour |  |
| `onecoin_clip_athens__019` | clip | — | CC BY 3.0 · Wikimedia Commons: Athens city tour |  |
| `onecoin_clip_athens__020` | clip | — | CC BY 3.0 · Wikimedia Commons: Athens city tour |  |
| `onecoin_clip_athens__021` | clip | — | CC BY 3.0 · Wikimedia Commons: Athens city tour |  |
| `onecoin_clip_athens__022` | clip | — | CC BY 3.0 · Wikimedia Commons: Athens city tour |  |
| `onecoin_clip_athens__023` | clip | — | CC BY 3.0 · Wikimedia Commons: Athens city tour |  |
| `onecoin_clip_athens__024` | clip | — | CC BY 3.0 · Wikimedia Commons: Athens city tour |  |
| `onecoin_clip_athens__025` | clip | — | CC BY 3.0 · Wikimedia Commons: Athens city tour |  |
| `onecoin_clip_athens__026` | clip | — | CC BY 3.0 · Wikimedia Commons: Athens city tour |  |
| `onecoin_clip_athens__027` | clip | — | CC BY 3.0 · Wikimedia Commons: Athens city tour |  |
| `onecoin_clip_athens__028` | clip | — | CC BY 3.0 · Wikimedia Commons: Athens city tour |  |
| `onecoin_clip_athens__029` | clip | — | CC BY 3.0 · Wikimedia Commons: Athens city tour |  |
| `onecoin_clip_athens__030` | clip | — | CC BY 3.0 · Wikimedia Commons: Athens city tour |  |
| `onecoin_clip_athens__031` | clip | — | CC BY 3.0 · Wikimedia Commons: Athens city tour |  |
| `onecoin_clip_athens__032` | clip | — | CC BY 3.0 · Wikimedia Commons: Athens city tour |  |
| `onecoin_clip_athens__033` | clip | — | CC BY 3.0 · Wikimedia Commons: Athens city tour |  |
| `onecoin_clip_athens__034` | clip | — | CC BY 3.0 · Wikimedia Commons: Athens city tour |  |
| `onecoin_clip_athens__035` | clip | — | CC BY 3.0 · Wikimedia Commons: Athens city tour |  |
| `onecoin_clip_city_night__000` | clip | — | CC BY 3.0 · Wikimedia Commons: City at night |  |
| `onecoin_clip_city_night__001` | clip | — | CC BY 3.0 · Wikimedia Commons: City at night |  |
| `onecoin_clip_city_night__002` | clip | — | CC BY 3.0 · Wikimedia Commons: City at night |  |
| `onecoin_clip_city_night__003` | clip | — | CC BY 3.0 · Wikimedia Commons: City at night |  |
| `onecoin_clip_city_night__004` | clip | — | CC BY 3.0 · Wikimedia Commons: City at night |  |
| `onecoin_clip_city_night__005` | clip | — | CC BY 3.0 · Wikimedia Commons: City at night |  |
| `onecoin_clip_city_night__006` | clip | — | CC BY 3.0 · Wikimedia Commons: City at night |  |
| `onecoin_clip_city_night__007` | clip | — | CC BY 3.0 · Wikimedia Commons: City at night |  |
| `onecoin_clip_city_night__008` | clip | — | CC BY 3.0 · Wikimedia Commons: City at night |  |
| `onecoin_clip_city_night__009` | clip | — | CC BY 3.0 · Wikimedia Commons: City at night |  |
| `onecoin_clip_city_night__010` | clip | — | CC BY 3.0 · Wikimedia Commons: City at night |  |
| `onecoin_clip_city_night__011` | clip | — | CC BY 3.0 · Wikimedia Commons: City at night |  |
| `onecoin_clip_city_night__012` | clip | — | CC BY 3.0 · Wikimedia Commons: City at night |  |
| `onecoin_clip_city_night__013` | clip | — | CC BY 3.0 · Wikimedia Commons: City at night |  |
| `onecoin_clip_city_night__014` | clip | — | CC BY 3.0 · Wikimedia Commons: City at night |  |
| `onecoin_clip_city_night__015` | clip | — | CC BY 3.0 · Wikimedia Commons: City at night |  |
| `onecoin_clip_city_night__016` | clip | — | CC BY 3.0 · Wikimedia Commons: City at night |  |
| `onecoin_clip_city_night__017` | clip | — | CC BY 3.0 · Wikimedia Commons: City at night |  |
| `onecoin_clip_city_night__018` | clip | — | CC BY 3.0 · Wikimedia Commons: City at night |  |
| `onecoin_clip_city_night__019` | clip | — | CC BY 3.0 · Wikimedia Commons: City at night |  |
| `onecoin_clip_city_night__020` | clip | — | CC BY 3.0 · Wikimedia Commons: City at night |  |
| `onecoin_clip_city_night__021` | clip | — | CC BY 3.0 · Wikimedia Commons: City at night |  |
| `onecoin_clip_city_night__022` | clip | — | CC BY 3.0 · Wikimedia Commons: City at night |  |
| `onecoin_clip_city_night__023` | clip | — | CC BY 3.0 · Wikimedia Commons: City at night |  |
| `onecoin_clip_city_night__024` | clip | — | CC BY 3.0 · Wikimedia Commons: City at night |  |
| `onecoin_clip_city_night__025` | clip | — | CC BY 3.0 · Wikimedia Commons: City at night |  |
| `onecoin_clip_city_night__026` | clip | — | CC BY 3.0 · Wikimedia Commons: City at night |  |
| `onecoin_clip_city_night__027` | clip | — | CC BY 3.0 · Wikimedia Commons: City at night |  |
| `onecoin_clip_city_night__028` | clip | — | CC BY 3.0 · Wikimedia Commons: City at night |  |
| `onecoin_clip_city_night__029` | clip | — | CC BY 3.0 · Wikimedia Commons: City at night |  |
| `onecoin_clip_city_night__030` | clip | — | CC BY 3.0 · Wikimedia Commons: City at night |  |
| `onecoin_clip_city_night__031` | clip | — | CC BY 3.0 · Wikimedia Commons: City at night |  |
| `onecoin_clip_city_night__032` | clip | — | CC BY 3.0 · Wikimedia Commons: City at night |  |
| `onecoin_clip_city_night__033` | clip | — | CC BY 3.0 · Wikimedia Commons: City at night |  |
| `onecoin_clip_city_night__034` | clip | — | CC BY 3.0 · Wikimedia Commons: City at night |  |
| `onecoin_clip_city_night__035` | clip | — | CC BY 3.0 · Wikimedia Commons: City at night |  |
| `onecoin_clip_datacenter__000` | clip | — | CC BY 3.0 · Wikimedia Commons: Data Center Tour |  |
| `onecoin_clip_datacenter__001` | clip | — | CC BY 3.0 · Wikimedia Commons: Data Center Tour |  |
| `onecoin_clip_datacenter__002` | clip | — | CC BY 3.0 · Wikimedia Commons: Data Center Tour |  |
| `onecoin_clip_datacenter__003` | clip | — | CC BY 3.0 · Wikimedia Commons: Data Center Tour |  |
| `onecoin_clip_datacenter__004` | clip | — | CC BY 3.0 · Wikimedia Commons: Data Center Tour |  |
| `onecoin_clip_datacenter__005` | clip | — | CC BY 3.0 · Wikimedia Commons: Data Center Tour |  |
| `onecoin_clip_datacenter__006` | clip | — | CC BY 3.0 · Wikimedia Commons: Data Center Tour |  |
| `onecoin_clip_datacenter__007` | clip | — | CC BY 3.0 · Wikimedia Commons: Data Center Tour |  |
| `onecoin_clip_datacenter__008` | clip | — | CC BY 3.0 · Wikimedia Commons: Data Center Tour |  |
| `onecoin_clip_datacenter__009` | clip | — | CC BY 3.0 · Wikimedia Commons: Data Center Tour |  |
| `onecoin_clip_datacenter__010` | clip | — | CC BY 3.0 · Wikimedia Commons: Data Center Tour |  |
| `onecoin_clip_datacenter__011` | clip | — | CC BY 3.0 · Wikimedia Commons: Data Center Tour |  |
| `onecoin_clip_datacenter__012` | clip | — | CC BY 3.0 · Wikimedia Commons: Data Center Tour |  |
| `onecoin_clip_datacenter__013` | clip | — | CC BY 3.0 · Wikimedia Commons: Data Center Tour |  |
| `onecoin_clip_datacenter__014` | clip | — | CC BY 3.0 · Wikimedia Commons: Data Center Tour |  |
| `onecoin_clip_datacenter__015` | clip | — | CC BY 3.0 · Wikimedia Commons: Data Center Tour |  |
| `onecoin_clip_datacenter__016` | clip | — | CC BY 3.0 · Wikimedia Commons: Data Center Tour |  |
| `onecoin_clip_datacenter__017` | clip | — | CC BY 3.0 · Wikimedia Commons: Data Center Tour |  |
| `onecoin_clip_datacenter__018` | clip | — | CC BY 3.0 · Wikimedia Commons: Data Center Tour |  |
| `onecoin_clip_datacenter__019` | clip | — | CC BY 3.0 · Wikimedia Commons: Data Center Tour |  |
| `onecoin_clip_datacenter__020` | clip | — | CC BY 3.0 · Wikimedia Commons: Data Center Tour |  |
| `onecoin_clip_datacenter__021` | clip | — | CC BY 3.0 · Wikimedia Commons: Data Center Tour |  |
| `onecoin_clip_datacenter__022` | clip | — | CC BY 3.0 · Wikimedia Commons: Data Center Tour |  |
| `onecoin_clip_datacenter__023` | clip | — | CC BY 3.0 · Wikimedia Commons: Data Center Tour |  |
| `onecoin_clip_datacenter__024` | clip | — | CC BY 3.0 · Wikimedia Commons: Data Center Tour |  |
| `onecoin_clip_datacenter__025` | clip | — | CC BY 3.0 · Wikimedia Commons: Data Center Tour |  |
| `onecoin_clip_datacenter__026` | clip | — | CC BY 3.0 · Wikimedia Commons: Data Center Tour |  |
| `onecoin_clip_datacenter__027` | clip | — | CC BY 3.0 · Wikimedia Commons: Data Center Tour |  |
| `onecoin_clip_datacenter__028` | clip | — | CC BY 3.0 · Wikimedia Commons: Data Center Tour |  |
| `onecoin_clip_datacenter__029` | clip | — | CC BY 3.0 · Wikimedia Commons: Data Center Tour |  |
| `onecoin_clip_datacenter__030` | clip | — | CC BY 3.0 · Wikimedia Commons: Data Center Tour |  |
| `onecoin_clip_datacenter__031` | clip | — | CC BY 3.0 · Wikimedia Commons: Data Center Tour |  |
| `onecoin_clip_datacenter__032` | clip | — | CC BY 3.0 · Wikimedia Commons: Data Center Tour |  |
| `onecoin_clip_datacenter__033` | clip | — | CC BY 3.0 · Wikimedia Commons: Data Center Tour |  |
| `onecoin_clip_datacenter__034` | clip | — | CC BY 3.0 · Wikimedia Commons: Data Center Tour |  |
| `onecoin_clip_datacenter__035` | clip | — | CC BY 3.0 · Wikimedia Commons: Data Center Tour |  |
| `onecoin_clip_harbour__000` | clip | — | CC0 · Wikimedia Commons: Aerial view of sea and boats |  |
| `onecoin_clip_harbour__001` | clip | — | CC0 · Wikimedia Commons: Aerial view of sea and boats |  |
| `onecoin_clip_harbour__002` | clip | — | CC0 · Wikimedia Commons: Aerial view of sea and boats |  |
| `onecoin_clip_harbour__003` | clip | — | CC0 · Wikimedia Commons: Aerial view of sea and boats |  |
| `onecoin_clip_harbour__004` | clip | — | CC0 · Wikimedia Commons: Aerial view of sea and boats |  |
| `onecoin_clip_harbour__005` | clip | — | CC0 · Wikimedia Commons: Aerial view of sea and boats |  |
| `onecoin_clip_harbour__006` | clip | — | CC0 · Wikimedia Commons: Aerial view of sea and boats |  |
| `onecoin_clip_harbour__007` | clip | — | CC0 · Wikimedia Commons: Aerial view of sea and boats |  |
| `onecoin_clip_harbour__008` | clip | — | CC0 · Wikimedia Commons: Aerial view of sea and boats |  |
| `onecoin_clip_harbour__009` | clip | — | CC0 · Wikimedia Commons: Aerial view of sea and boats |  |
| `onecoin_clip_harbour__010` | clip | — | CC0 · Wikimedia Commons: Aerial view of sea and boats |  |
| `onecoin_clip_harbour__011` | clip | — | CC0 · Wikimedia Commons: Aerial view of sea and boats |  |
| `onecoin_clip_harbour__012` | clip | — | CC0 · Wikimedia Commons: Aerial view of sea and boats |  |
| `onecoin_clip_harbour__013` | clip | — | CC0 · Wikimedia Commons: Aerial view of sea and boats |  |
| `onecoin_clip_harbour__014` | clip | — | CC0 · Wikimedia Commons: Aerial view of sea and boats |  |
| `onecoin_clip_harbour__015` | clip | — | CC0 · Wikimedia Commons: Aerial view of sea and boats |  |
| `onecoin_clip_harbour__016` | clip | — | CC0 · Wikimedia Commons: Aerial view of sea and boats |  |
| `onecoin_clip_harbour__017` | clip | — | CC0 · Wikimedia Commons: Aerial view of sea and boats |  |
| `onecoin_clip_harbour__018` | clip | — | CC0 · Wikimedia Commons: Aerial view of sea and boats |  |
| `onecoin_clip_harbour__019` | clip | — | CC0 · Wikimedia Commons: Aerial view of sea and boats |  |
| `onecoin_clip_harbour__020` | clip | — | CC0 · Wikimedia Commons: Aerial view of sea and boats |  |
| `onecoin_clip_harbour__021` | clip | — | CC0 · Wikimedia Commons: Aerial view of sea and boats |  |
| `onecoin_clip_harbour__022` | clip | — | CC0 · Wikimedia Commons: Aerial view of sea and boats |  |
| `onecoin_clip_harbour__023` | clip | — | CC0 · Wikimedia Commons: Aerial view of sea and boats |  |
| `onecoin_clip_harbour__024` | clip | — | CC0 · Wikimedia Commons: Aerial view of sea and boats |  |
| `onecoin_clip_harbour__025` | clip | — | CC0 · Wikimedia Commons: Aerial view of sea and boats |  |
| `onecoin_clip_harbour__026` | clip | — | CC0 · Wikimedia Commons: Aerial view of sea and boats |  |
| `onecoin_clip_harbour__027` | clip | — | CC0 · Wikimedia Commons: Aerial view of sea and boats |  |
| `onecoin_clip_harbour__028` | clip | — | CC0 · Wikimedia Commons: Aerial view of sea and boats |  |
| `onecoin_clip_harbour__029` | clip | — | CC0 · Wikimedia Commons: Aerial view of sea and boats |  |
| `onecoin_clip_harbour__030` | clip | — | CC0 · Wikimedia Commons: Aerial view of sea and boats |  |
| `onecoin_clip_harbour__031` | clip | — | CC0 · Wikimedia Commons: Aerial view of sea and boats |  |
| `onecoin_clip_harbour__032` | clip | — | CC0 · Wikimedia Commons: Aerial view of sea and boats |  |
| `onecoin_clip_harbour__033` | clip | — | CC0 · Wikimedia Commons: Aerial view of sea and boats |  |
| `onecoin_clip_harbour__034` | clip | — | CC0 · Wikimedia Commons: Aerial view of sea and boats |  |
| `onecoin_clip_harbour__035` | clip | — | CC0 · Wikimedia Commons: Aerial view of sea and boats |  |
| `onecoin_clip_mining_asic__000` | clip | — | CC BY-SA 4.0 · Wikimedia Commons: ASIC Bitcoin miner |  |
| `onecoin_clip_mining_asic__001` | clip | — | CC BY-SA 4.0 · Wikimedia Commons: ASIC Bitcoin miner |  |
| `onecoin_clip_mining_asic__002` | clip | — | CC BY-SA 4.0 · Wikimedia Commons: ASIC Bitcoin miner |  |
| `onecoin_clip_mining_asic__003` | clip | — | CC BY-SA 4.0 · Wikimedia Commons: ASIC Bitcoin miner |  |
| `onecoin_clip_mining_asic__004` | clip | — | CC BY-SA 4.0 · Wikimedia Commons: ASIC Bitcoin miner |  |
| `onecoin_clip_mining_asic__005` | clip | — | CC BY-SA 4.0 · Wikimedia Commons: ASIC Bitcoin miner |  |
| `onecoin_clip_mining_asic__006` | clip | — | CC BY-SA 4.0 · Wikimedia Commons: ASIC Bitcoin miner |  |
| `onecoin_clip_mining_asic__007` | clip | — | CC BY-SA 4.0 · Wikimedia Commons: ASIC Bitcoin miner |  |
| `onecoin_clip_mining_asic__008` | clip | — | CC BY-SA 4.0 · Wikimedia Commons: ASIC Bitcoin miner |  |
| `onecoin_clip_mining_asic__009` | clip | — | CC BY-SA 4.0 · Wikimedia Commons: ASIC Bitcoin miner |  |
| `onecoin_clip_mining_asic__010` | clip | — | CC BY-SA 4.0 · Wikimedia Commons: ASIC Bitcoin miner |  |
| `onecoin_clip_mining_asic__011` | clip | — | CC BY-SA 4.0 · Wikimedia Commons: ASIC Bitcoin miner |  |
| `onecoin_clip_mining_asic__012` | clip | — | CC BY-SA 4.0 · Wikimedia Commons: ASIC Bitcoin miner |  |
| `onecoin_clip_mining_asic__013` | clip | — | CC BY-SA 4.0 · Wikimedia Commons: ASIC Bitcoin miner |  |
| `onecoin_clip_mining_asic__014` | clip | — | CC BY-SA 4.0 · Wikimedia Commons: ASIC Bitcoin miner |  |
| `onecoin_clip_mining_asic__015` | clip | — | CC BY-SA 4.0 · Wikimedia Commons: ASIC Bitcoin miner |  |
| `onecoin_clip_mining_asic__016` | clip | — | CC BY-SA 4.0 · Wikimedia Commons: ASIC Bitcoin miner |  |
| `onecoin_clip_mining_asic__017` | clip | — | CC BY-SA 4.0 · Wikimedia Commons: ASIC Bitcoin miner |  |
| `onecoin_clip_mining_asic__018` | clip | — | CC BY-SA 4.0 · Wikimedia Commons: ASIC Bitcoin miner |  |
| `onecoin_clip_mining_asic__019` | clip | — | CC BY-SA 4.0 · Wikimedia Commons: ASIC Bitcoin miner |  |
| `onecoin_clip_mining_asic__020` | clip | — | CC BY-SA 4.0 · Wikimedia Commons: ASIC Bitcoin miner |  |
| `onecoin_clip_mining_asic__021` | clip | — | CC BY-SA 4.0 · Wikimedia Commons: ASIC Bitcoin miner |  |
| `onecoin_clip_mining_asic__022` | clip | — | CC BY-SA 4.0 · Wikimedia Commons: ASIC Bitcoin miner |  |
| `onecoin_clip_mining_asic__023` | clip | — | CC BY-SA 4.0 · Wikimedia Commons: ASIC Bitcoin miner |  |
| `onecoin_clip_mining_asic__024` | clip | — | CC BY-SA 4.0 · Wikimedia Commons: ASIC Bitcoin miner |  |
| `onecoin_clip_mining_asic__025` | clip | — | CC BY-SA 4.0 · Wikimedia Commons: ASIC Bitcoin miner |  |
| `onecoin_clip_mining_asic__026` | clip | — | CC BY-SA 4.0 · Wikimedia Commons: ASIC Bitcoin miner |  |
| `onecoin_clip_mining_asic__027` | clip | — | CC BY-SA 4.0 · Wikimedia Commons: ASIC Bitcoin miner |  |
| `onecoin_clip_mining_asic__028` | clip | — | CC BY-SA 4.0 · Wikimedia Commons: ASIC Bitcoin miner |  |
| `onecoin_clip_mining_asic__029` | clip | — | CC BY-SA 4.0 · Wikimedia Commons: ASIC Bitcoin miner |  |
| `onecoin_clip_mining_asic__030` | clip | — | CC BY-SA 4.0 · Wikimedia Commons: ASIC Bitcoin miner |  |
| `onecoin_clip_mining_asic__031` | clip | — | CC BY-SA 4.0 · Wikimedia Commons: ASIC Bitcoin miner |  |
| `onecoin_clip_mining_asic__032` | clip | — | CC BY-SA 4.0 · Wikimedia Commons: ASIC Bitcoin miner |  |
| `onecoin_clip_mining_asic__033` | clip | — | CC BY-SA 4.0 · Wikimedia Commons: ASIC Bitcoin miner |  |
| `onecoin_clip_mining_asic__034` | clip | — | CC BY-SA 4.0 · Wikimedia Commons: ASIC Bitcoin miner |  |
| `onecoin_clip_mining_asic__035` | clip | — | CC BY-SA 4.0 · Wikimedia Commons: ASIC Bitcoin miner |  |
| `onecoin_clip_rain_window__000` | clip | — | CC0 · Wikimedia Commons: Raindrops against the window, Las Palmas |  |
| `onecoin_clip_rain_window__001` | clip | — | CC0 · Wikimedia Commons: Raindrops against the window, Las Palmas |  |
| `onecoin_clip_rain_window__002` | clip | — | CC0 · Wikimedia Commons: Raindrops against the window, Las Palmas |  |
| `onecoin_clip_rain_window__003` | clip | — | CC0 · Wikimedia Commons: Raindrops against the window, Las Palmas |  |
| `onecoin_clip_rain_window__004` | clip | — | CC0 · Wikimedia Commons: Raindrops against the window, Las Palmas |  |
| `onecoin_clip_rain_window__005` | clip | — | CC0 · Wikimedia Commons: Raindrops against the window, Las Palmas |  |
| `onecoin_clip_rain_window__006` | clip | — | CC0 · Wikimedia Commons: Raindrops against the window, Las Palmas |  |
| `onecoin_clip_rain_window__007` | clip | — | CC0 · Wikimedia Commons: Raindrops against the window, Las Palmas |  |
| `onecoin_clip_rain_window__008` | clip | — | CC0 · Wikimedia Commons: Raindrops against the window, Las Palmas |  |
| `onecoin_clip_rain_window__009` | clip | — | CC0 · Wikimedia Commons: Raindrops against the window, Las Palmas |  |
| `onecoin_clip_rain_window__010` | clip | — | CC0 · Wikimedia Commons: Raindrops against the window, Las Palmas |  |
| `onecoin_clip_rain_window__011` | clip | — | CC0 · Wikimedia Commons: Raindrops against the window, Las Palmas |  |
| `onecoin_clip_rain_window__012` | clip | — | CC0 · Wikimedia Commons: Raindrops against the window, Las Palmas |  |
| `onecoin_clip_rain_window__013` | clip | — | CC0 · Wikimedia Commons: Raindrops against the window, Las Palmas |  |
| `onecoin_clip_rain_window__014` | clip | — | CC0 · Wikimedia Commons: Raindrops against the window, Las Palmas |  |
| `onecoin_clip_rain_window__015` | clip | — | CC0 · Wikimedia Commons: Raindrops against the window, Las Palmas |  |
| `onecoin_clip_rain_window__016` | clip | — | CC0 · Wikimedia Commons: Raindrops against the window, Las Palmas |  |
| `onecoin_clip_rain_window__017` | clip | — | CC0 · Wikimedia Commons: Raindrops against the window, Las Palmas |  |
| `onecoin_clip_rain_window__018` | clip | — | CC0 · Wikimedia Commons: Raindrops against the window, Las Palmas |  |
| `onecoin_clip_rain_window__019` | clip | — | CC0 · Wikimedia Commons: Raindrops against the window, Las Palmas |  |
| `onecoin_clip_rain_window__020` | clip | — | CC0 · Wikimedia Commons: Raindrops against the window, Las Palmas |  |
| `onecoin_clip_rain_window__021` | clip | — | CC0 · Wikimedia Commons: Raindrops against the window, Las Palmas |  |
| `onecoin_clip_rain_window__022` | clip | — | CC0 · Wikimedia Commons: Raindrops against the window, Las Palmas |  |
| `onecoin_clip_rain_window__023` | clip | — | CC0 · Wikimedia Commons: Raindrops against the window, Las Palmas |  |
| `onecoin_clip_rain_window__024` | clip | — | CC0 · Wikimedia Commons: Raindrops against the window, Las Palmas |  |
| `onecoin_clip_rain_window__025` | clip | — | CC0 · Wikimedia Commons: Raindrops against the window, Las Palmas |  |
| `onecoin_clip_rain_window__026` | clip | — | CC0 · Wikimedia Commons: Raindrops against the window, Las Palmas |  |
| `onecoin_clip_rain_window__027` | clip | — | CC0 · Wikimedia Commons: Raindrops against the window, Las Palmas |  |
| `onecoin_clip_rain_window__028` | clip | — | CC0 · Wikimedia Commons: Raindrops against the window, Las Palmas |  |
| `onecoin_clip_rain_window__029` | clip | — | CC0 · Wikimedia Commons: Raindrops against the window, Las Palmas |  |
| `onecoin_clip_rain_window__030` | clip | — | CC0 · Wikimedia Commons: Raindrops against the window, Las Palmas |  |
| `onecoin_clip_rain_window__031` | clip | — | CC0 · Wikimedia Commons: Raindrops against the window, Las Palmas |  |
| `onecoin_clip_rain_window__032` | clip | — | CC0 · Wikimedia Commons: Raindrops against the window, Las Palmas |  |
| `onecoin_clip_rain_window__033` | clip | — | CC0 · Wikimedia Commons: Raindrops against the window, Las Palmas |  |
| `onecoin_clip_rain_window__034` | clip | — | CC0 · Wikimedia Commons: Raindrops against the window, Las Palmas |  |
| `onecoin_clip_rain_window__035` | clip | — | CC0 · Wikimedia Commons: Raindrops against the window, Las Palmas |  |
| `onecoin_clip_ruja_close__000` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_close__001` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_close__002` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_close__003` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_close__004` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_close__005` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_close__006` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_close__007` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_close__008` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_close__009` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_close__010` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_close__011` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_close__012` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_close__013` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_close__014` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_close__015` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_close__016` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_close__017` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_close__018` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_close__019` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_close__020` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_close__021` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_close__022` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_close__023` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_close__024` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_close__025` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_close__026` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_close__027` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_close__028` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_close__029` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_close__030` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_close__031` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_close__032` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_close__033` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_close__034` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_close__035` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_close__036` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_close__037` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_close__038` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_close__039` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_close__040` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_close__041` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_close__042` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_close__043` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_close__044` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_close__045` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_close__046` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_close__047` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_stage__000` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_stage__001` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_stage__002` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_stage__003` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_stage__004` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_stage__005` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_stage__006` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_stage__007` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_stage__008` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_stage__009` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_stage__010` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_stage__011` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_stage__012` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_stage__013` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_stage__014` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_stage__015` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_stage__016` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_stage__017` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_stage__018` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_stage__019` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_stage__020` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_stage__021` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_stage__022` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_stage__023` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_stage__024` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_stage__025` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_stage__026` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_stage__027` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_stage__028` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_stage__029` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_stage__030` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_stage__031` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_stage__032` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_stage__033` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_stage__034` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_stage__035` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_stage__036` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_stage__037` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_stage__038` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_stage__039` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_stage__040` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_stage__041` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_stage__042` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_stage__043` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_stage__044` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_stage__045` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_stage__046` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_ruja_stage__047` | clip | — | Public domain · FBI: Ruja Ignatova at OneCoin London event (public domain) |  |
| `onecoin_clip_takeoff__000` | clip | — | CC BY 3.0 · Wikimedia Commons: United Airlines 737 takeoff, Portland |  |
| `onecoin_clip_takeoff__001` | clip | — | CC BY 3.0 · Wikimedia Commons: United Airlines 737 takeoff, Portland |  |
| `onecoin_clip_takeoff__002` | clip | — | CC BY 3.0 · Wikimedia Commons: United Airlines 737 takeoff, Portland |  |
| `onecoin_clip_takeoff__003` | clip | — | CC BY 3.0 · Wikimedia Commons: United Airlines 737 takeoff, Portland |  |
| `onecoin_clip_takeoff__004` | clip | — | CC BY 3.0 · Wikimedia Commons: United Airlines 737 takeoff, Portland |  |
| `onecoin_clip_takeoff__005` | clip | — | CC BY 3.0 · Wikimedia Commons: United Airlines 737 takeoff, Portland |  |
| `onecoin_clip_takeoff__006` | clip | — | CC BY 3.0 · Wikimedia Commons: United Airlines 737 takeoff, Portland |  |
| `onecoin_clip_takeoff__007` | clip | — | CC BY 3.0 · Wikimedia Commons: United Airlines 737 takeoff, Portland |  |
| `onecoin_clip_takeoff__008` | clip | — | CC BY 3.0 · Wikimedia Commons: United Airlines 737 takeoff, Portland |  |
| `onecoin_clip_takeoff__009` | clip | — | CC BY 3.0 · Wikimedia Commons: United Airlines 737 takeoff, Portland |  |
| `onecoin_clip_takeoff__010` | clip | — | CC BY 3.0 · Wikimedia Commons: United Airlines 737 takeoff, Portland |  |
| `onecoin_clip_takeoff__011` | clip | — | CC BY 3.0 · Wikimedia Commons: United Airlines 737 takeoff, Portland |  |
| `onecoin_clip_takeoff__012` | clip | — | CC BY 3.0 · Wikimedia Commons: United Airlines 737 takeoff, Portland |  |
| `onecoin_clip_takeoff__013` | clip | — | CC BY 3.0 · Wikimedia Commons: United Airlines 737 takeoff, Portland |  |
| `onecoin_clip_takeoff__014` | clip | — | CC BY 3.0 · Wikimedia Commons: United Airlines 737 takeoff, Portland |  |
| `onecoin_clip_takeoff__015` | clip | — | CC BY 3.0 · Wikimedia Commons: United Airlines 737 takeoff, Portland |  |
| `onecoin_clip_takeoff__016` | clip | — | CC BY 3.0 · Wikimedia Commons: United Airlines 737 takeoff, Portland |  |
| `onecoin_clip_takeoff__017` | clip | — | CC BY 3.0 · Wikimedia Commons: United Airlines 737 takeoff, Portland |  |
| `onecoin_clip_takeoff__018` | clip | — | CC BY 3.0 · Wikimedia Commons: United Airlines 737 takeoff, Portland |  |
| `onecoin_clip_takeoff__019` | clip | — | CC BY 3.0 · Wikimedia Commons: United Airlines 737 takeoff, Portland |  |
| `onecoin_clip_takeoff__020` | clip | — | CC BY 3.0 · Wikimedia Commons: United Airlines 737 takeoff, Portland |  |
| `onecoin_clip_takeoff__021` | clip | — | CC BY 3.0 · Wikimedia Commons: United Airlines 737 takeoff, Portland |  |
| `onecoin_clip_takeoff__022` | clip | — | CC BY 3.0 · Wikimedia Commons: United Airlines 737 takeoff, Portland |  |
| `onecoin_clip_takeoff__023` | clip | — | CC BY 3.0 · Wikimedia Commons: United Airlines 737 takeoff, Portland |  |
| `onecoin_clip_takeoff__024` | clip | — | CC BY 3.0 · Wikimedia Commons: United Airlines 737 takeoff, Portland |  |
| `onecoin_clip_takeoff__025` | clip | — | CC BY 3.0 · Wikimedia Commons: United Airlines 737 takeoff, Portland |  |
| `onecoin_clip_takeoff__026` | clip | — | CC BY 3.0 · Wikimedia Commons: United Airlines 737 takeoff, Portland |  |
| `onecoin_clip_takeoff__027` | clip | — | CC BY 3.0 · Wikimedia Commons: United Airlines 737 takeoff, Portland |  |
| `onecoin_clip_takeoff__028` | clip | — | CC BY 3.0 · Wikimedia Commons: United Airlines 737 takeoff, Portland |  |
| `onecoin_clip_takeoff__029` | clip | — | CC BY 3.0 · Wikimedia Commons: United Airlines 737 takeoff, Portland |  |
| `onecoin_clip_takeoff__030` | clip | — | CC BY 3.0 · Wikimedia Commons: United Airlines 737 takeoff, Portland |  |
| `onecoin_clip_takeoff__031` | clip | — | CC BY 3.0 · Wikimedia Commons: United Airlines 737 takeoff, Portland |  |
| `onecoin_clip_takeoff__032` | clip | — | CC BY 3.0 · Wikimedia Commons: United Airlines 737 takeoff, Portland |  |
| `onecoin_clip_takeoff__033` | clip | — | CC BY 3.0 · Wikimedia Commons: United Airlines 737 takeoff, Portland |  |
| `onecoin_clip_takeoff__034` | clip | — | CC BY 3.0 · Wikimedia Commons: United Airlines 737 takeoff, Portland |  |
| `onecoin_clip_takeoff__035` | clip | — | CC BY 3.0 · Wikimedia Commons: United Airlines 737 takeoff, Portland |  |
| `onecoin_bartlett` | cut | Jamie Bartlett, British journalist (author of The Missing Cryptoqueen), portrait at a conference, vertical frame. | CC BY 2.0 · Európa Pont / Wikimedia Commons (CC BY 2.0) |  |
| `onecoin_el_ankle_tag` | cut | AI cut-out: an electronic ankle monitoring tag with charging cable. | AI-generated illustration (Muse generate_image) | AI |
| `onecoin_el_champagne` | cut | AI cut-out: a champagne bottle with two filled flutes. | AI-generated illustration (Muse generate_image) | AI |
| `onecoin_el_corkboard` | cut | AI cut-out: a corkboard with photographs, blank note cards and red string between pins. | AI-generated illustration (Muse generate_image) | AI |
| `onecoin_el_gold_coin` | cut | AI cut-out: a single large golden coin with a plain embossed ring, upright. Generic coin, no logo, for parallax overlays. | AI-generated illustration (Muse generate_image) | AI |
| `onecoin_el_gown` | cut | AI cut-out: a deep red evening ball gown on a tailor's mannequin. | AI-generated illustration (Muse generate_image) | AI |
| `onecoin_el_handcuffs` | cut | AI cut-out: a pair of steel handcuffs on a dark surface. | AI-generated illustration (Muse generate_image) | AI |
| `onecoin_el_jet` | cut | AI cut-out: a sleek private jet on a dark runway at night, cabin windows glowing. | AI-generated illustration (Muse generate_image) | AI |
| `onecoin_el_microphone` | cut | AI cut-out: a vintage chrome microphone on a stand. | AI-generated illustration (Muse generate_image) | AI |
| `onecoin_el_passport` | cut | AI cut-out: a plain dark passport booklet with a paper boarding pass tucked in, cover blank. | AI-generated illustration (Muse generate_image) | AI |
| `onecoin_el_server` | cut | AI cut-out: a tall black server rack with small blinking lights. | AI-generated illustration (Muse generate_image) | AI |
| `onecoin_el_vault_wheel` | cut | AI cut-out: a bank vault door with a large wheel handle, slightly ajar, warm light inside. | AI-generated illustration (Muse generate_image) | AI |
| `onecoin_el_yacht` | cut | AI cut-out: a white superyacht at anchor on dark water at dusk. | AI-generated illustration (Muse generate_image) | AI |
| `onecoin_ruja` | cut | Portrait of Ruja Ignatova, head and shoulders, dark hair, facing camera. Square crop, subject centred. Use as the main person cut-out. | CC BY-SA 2.0 · OneCoin Coporation / Wikimedia Commons (CC BY-SA 2.0) |  |
| `onecoin_art_airport_dawn` | plate | AI plate, luxury look: a lone woman with a cabin bag walking away through a dawn airport terminal, long shadow. Sofia airport, 25 October 2017. | AI-generated illustration (Muse generate_image) | AI |
| `onecoin_art_ankle_desk` | plate | AI plate, luxury look: a quiet room seen through a window, an ankle monitor charging on a desk, striped blind light. Schneider's house arrest in France. | AI-generated illustration (Muse generate_image) | AI |
| `onecoin_art_athens_light` | plate | AI plate, luxury look: a Mediterranean arrivals hall flooded with morning light, a lone traveller from behind heading for the exit. Athens, the last confirmed point. | AI-generated illustration (Muse generate_image) | AI |
| `onecoin_art_checkin_hand` | plate | AI plate, luxury look: a hand sliding a passport and boarding pass across a check-in desk in morning light. The one-way ticket. | AI-generated illustration (Muse generate_image) | AI |
| `onecoin_art_courtroom` | plate | AI plate, luxury look: an empty wood-panelled courtroom, flags, a shaft of window light. The SDNY reckoning. | AI-generated illustration (Muse generate_image) | AI |
| `onecoin_art_database_room` | plate | AI plate, luxury look: a dark back office at night, one monitor glowing with an abstract data grid, empty chairs. The database instead of a blockchain. | AI-generated illustration (Muse generate_image) | AI |
| `onecoin_art_dubai_fountain` | plate | AI plate, luxury look: a lone figure from behind watches a golden fountain show between towers at night. | AI-generated illustration (Muse generate_image) | AI |
| `onecoin_art_empty_stage` | plate | AI plate, luxury look: an empty arena stage after the show, one microphone stand in a spotlight, confetti on the floor. | AI-generated illustration (Muse generate_image) | AI |
| `onecoin_art_frosted_doors` | plate | AI plate, luxury look: two frosted glass doors with blank brass nameplates in a marble lobby. The Fenero Funds' paper front. | AI-generated illustration (Muse generate_image) | AI |
| `onecoin_art_gala_table` | plate | AI plate, luxury look: an opulent gala table set for many, crystal and gold, every chair empty, candles low. | AI-generated illustration (Muse generate_image) | AI |
| `onecoin_art_investigation_wall` | plate | AI plate, luxury look: an investigation wall in a dark room, photos and blank cards joined by red string, one desk lamp. | AI-generated illustration (Muse generate_image) | AI |
| `onecoin_art_lax_cuffs` | plate | AI plate, luxury look: hands in handcuffs resting on a suitcase handle in an airport jetway, shallow focus. Konstantin's arrest at LAX. | AI-generated illustration (Muse generate_image) | AI |
| `onecoin_art_lisbon_chair` | plate | AI plate, luxury look: a conference stage, rows of empty chairs, one chair in a spotlight. Lisbon, 7 October 2017, the event she never showed up for. | AI-generated illustration (Muse generate_image) | AI |
| `onecoin_art_london_door` | plate | AI plate, luxury look: a grand London townhouse door with brass knocker in evening rain light, wet pavement. | AI-generated illustration (Muse generate_image) | AI |
| `onecoin_art_mansion_sea` | plate | AI plate, luxury look: a modern mansion on a cliff above a dark sea, windows black, gates closed. The Sozopol house after she vanished. | AI-generated illustration (Muse generate_image) | AI |
| `onecoin_art_mood_city` | plate | AI mood plate, luxury look: a capital city at night from high above, rivers of gold traffic light under low cloud. | AI-generated illustration (Muse generate_image) | AI |
| `onecoin_art_mood_fog` | plate | AI mood plate, luxury look: a harbour in thick sea fog at dawn, masts fading into white silence. | AI-generated illustration (Muse generate_image) | AI |
| `onecoin_art_mood_lobby` | plate | AI mood plate, luxury look: an empty marble corporate lobby at night, one reception desk, polished reflections. | AI-generated illustration (Muse generate_image) | AI |
| `onecoin_art_mood_rain` | plate | AI mood plate, luxury look: rain running down a dark window at night, gold city lights smeared behind the glass. | AI-generated illustration (Muse generate_image) | AI |
| `onecoin_art_mood_runway` | plate | AI mood plate, luxury look: an airport runway at first light, rows of small gold lights leading into mist. | AI-generated illustration (Muse generate_image) | AI |
| `onecoin_art_mood_trading_floor` | plate | AI mood plate, luxury look: a vast empty trading floor before dawn, rows of dark monitors, one screen glowing. | AI-generated illustration (Muse generate_image) | AI |
| `onecoin_art_penthouse` | plate | AI plate, luxury look: an untouched luxury penthouse above a night city, champagne on ice, two glasses, nobody home. The Kensington flat. | AI-generated illustration (Muse generate_image) | AI |
| `onecoin_art_podcast_wall` | plate | AI plate, luxury look: a podcast studio corner, two microphones, a corkboard of photographs and red string. The Missing Cryptoqueen investigation. | AI-generated illustration (Muse generate_image) | AI |
| `onecoin_art_poster_wall` | plate | AI plate, luxury look: a weathered wanted-style poster with a blurred portrait on a city wall, passers-by blurred, nobody stopping. | AI-generated illustration (Muse generate_image) | AI |
| `onecoin_art_press_table` | plate | AI plate, luxury look: a long press table with microphones and empty chairs, camera flashes. The announcements nobody from OneCoin attended. | AI-generated illustration (Muse generate_image) | AI |
| `onecoin_art_raid_office` | plate | AI plate, luxury look: an office corridor at dawn, doors open, archive boxes and scattered files, torch beams. The Sofia raid, January 2018. | AI-generated illustration (Muse generate_image) | AI |
| `onecoin_art_recruit_call` | plate | AI plate, luxury look: a hand holding a telephone receiver at a desk with notebook and laptop, night city behind glass. The 2016 call in which a recruiter admitted there was no blockchain. | AI-generated illustration (Muse generate_image) | AI |
| `onecoin_art_salon_pitch` | plate | AI plate, luxury look: a woman in an emerald gown seen from behind pitches a small circle of investors in a grand salon, chandelier light. The 2014 beginnings. | AI-generated illustration (Muse generate_image) | AI |
| `onecoin_art_server_glow` | plate | AI plate, luxury look: a dark data centre corridor, endless racks, one rack blinking amber. The mining that was a timer on a database. | AI-generated illustration (Muse generate_image) | AI |
| `onecoin_art_split_champagne` | plate | AI plate, luxury look: champagne poured in a dark boardroom, a glowing golden rising curve reflected in the glass wall. The split parties. | AI-generated illustration (Muse generate_image) | AI |
| `onecoin_art_thailand_villa` | plate | AI plate, luxury look: a tropical villa at dusk, glowing pool, suitcases by the open door. Greenwood's life before the Thailand arrest. | AI-generated illustration (Muse generate_image) | AI |
| `onecoin_art_uganda_plot` | plate | AI plate, luxury look: a small farm plot at dusk, a lone figure from far behind at the field edge, a ledger on a stool. The Ugandan victims. | AI-generated illustration (Muse generate_image) | AI |
| `onecoin_art_vault_glow` | plate | AI plate, luxury look: a round vault door ajar, warm golden light spilling over a marble floor. The laundering layer. | AI-generated illustration (Muse generate_image) | AI |
| `onecoin_art_victim_kitchen` | plate | AI plate, luxury look: a modest kitchen table at night, unpaid bills, a dark laptop, cold tea, one chair pulled out. The victims' side of the ledger. | AI-generated illustration (Muse generate_image) | AI |
| `onecoin_art_wembley_gown` | plate | AI plate, luxury look: a lone woman in a flowing red ball gown on a dark arena stage, seen from behind, facing a sea of phone lights in golden haze. The Wembley coronation, June 2016. | AI-generated illustration (Muse generate_image) | AI |
| `onecoin_art_yacht_harbour` | plate | AI plate, luxury look: a white superyacht moored alone in a quiet harbour at dusk, nobody aboard. The yacht Davina, left in Sozopol. | AI-generated illustration (Muse generate_image) | AI |
| `onecoin_athens_airport` | plate | Athens International Airport terminal exterior, landscape. She flew Sofia to Athens on 25 October 2017 and vanished. | CC BY-SA 4.0 · Apaleutos25 / Wikimedia Commons (CC BY-SA 4.0) |  |
| `onecoin_bangkok` | plate | Bangkok skyline at night, where Greenwood was held before extradition to the US. | CC BY-SA 4.0 · Slyronit / Wikimedia Commons (CC BY-SA 4.0) |  |
| `onecoin_black_sea` | plate | Bulgarian Black Sea coast at Topola. She kept a mansion and the yacht Davina at Sozopol on this coast. | CC BY-SA 4.0 · עמיחי אביב / Wikimedia Commons (CC BY-SA 4.0) |  |
| `onecoin_canary_wharf` | plate | Canary Wharf, London financial district. The UK FCA warned about OneCoin in September 2016. | CC BY-SA 4.0 · Dietmar Rabich / Wikimedia Commons (CC BY-SA 4.0) |  |
| `onecoin_cape_town` | plate | Cape Town and Table Mountain, 2024 photograph. Reported (unconfirmed) sightings and the Kamenov murder link the hunt to Cape Town. | CC BY-SA 4.0 · Dietmar Rabich / Wikimedia Commons (CC BY-SA 4.0) |  |
| `onecoin_court_sdny` | plate | Thurgood Marshall United States Courthouse, Foley Square, New York, vertical. SDNY courthouse where the trials and pleas happened. | CC BY-SA 3.0 · Americasroof / Wikimedia Commons (CC BY-SA 3.0) |  |
| `onecoin_courtroom_photo` | plate | Interior of the European Court of Human Rights courtroom, wood benches and blue seats. Generic courtroom plate. | CC BY-SA 3.0 pl · Adrian Grycuk / Wikimedia Commons (CC BY-SA 3.0 pl) |  |
| `onecoin_departures` | plate | Airport departures board with flight listings, Brisbane Airport photograph. Generic departures plate. | CC BY-SA 4.0 · Kgbo / Wikimedia Commons (CC BY-SA 4.0) |  |
| `onecoin_dubai` | plate | Dubai skyline with Burj Khalifa, CC0 photograph, landscape. OneCoin entities and money touched Dubai. | CC0 · Robert Bock / Wikimedia Commons (CC0) |  |
| `onecoin_fbi_hq` | plate | FBI Headquarters, the J. Edgar Hoover Building, Washington DC. | CC BY 2.0 · ajay_suresh / Wikimedia Commons (CC BY 2.0) |  |
| `onecoin_hague` | plate | Aerial view of The Hague city centre. Europol coordinated the case and listed her among Europe's most wanted. | CC BY 2.0 · Dmitry Eliuseev / Wikimedia Commons (CC BY 2.0) |  |
| `onecoin_hq_office` | plate | The real OneCoin office building in Sofia, Bulgaria, vertical photo, signage visible. Raided in January 2018. | CC BY-SA 3.0 · Ronny Martin Junnilainen / Wikimedia Commons (CC BY-SA 3.0) |  |
| `onecoin_kensington` | plate | Kensington High Street, London. Her £12.5m+ penthouse was bought through Guernsey shell companies here. | CC BY-SA 2.5 · No machine-readable author provided. Thomas Blomberg assumed (based on copyright claims). / Wikimedia Commons (CC BY-SA 2.5) |  |
| `onecoin_koh_samui` | plate | Beach on Koh Samui, Thailand. Sebastian Greenwood was arrested on Koh Samui in July 2018. | CC BY 4.0 · Vyacheslav Argenberg / Wikimedia Commons (CC BY 4.0) |  |
| `onecoin_konstanz` | plate | Old town rooftops of Konstanz, Germany. She took her law PhD at the University of Konstanz in 2005. | CC BY 2.0 · Jose Hidalgo from Punta Arenas y South Lake Tahoe, Chile y California / Wikimedia Commons (CC BY 2.0) |  |
| `onecoin_lax` | plate | Aerial view of Los Angeles International Airport and surroundings. Konstantin Ignatov was arrested at LAX on 6 March 2019. | CC0 · Alfred Twu / Wikimedia Commons (CC0) |  |
| `onecoin_luxembourg` | plate | Luxembourg City old town at night, panoramic. Frank Schneider was a former Luxembourg intelligence officer. | CC BY-SA 3.0 · Benh LIEU SONG / Wikimedia Commons (CC BY-SA 3.0) |  |
| `onecoin_macau` | plate | Macau skyline. OneCoin staged major promoter events in Macau. | CC BY 3.0 · Mike / Wikimedia Commons (CC BY 3.0) |  |
| `onecoin_oxford` | plate | Oxford High Street and University College. She marketed an Oxford connection; the credential was a master's in European law. | CC BY-SA 4.0 · Txllxt TxllxT / Wikimedia Commons (CC BY-SA 4.0) |  |
| `onecoin_prison` | plate | Barbed wire in winter, close photograph. Generic prison/exile plate for the sentences. | CC BY 3.0 · Vesa Linja-aho / Wikimedia Commons (CC BY 3.0) |  |
| `onecoin_private_jet` | plate | Business-class cabin interior (Jet Airways 777). Generic luxury cabin plate for the money trail. | CC BY 2.0 · schuey from London, London / Wikimedia Commons (CC BY 2.0) |  |
| `onecoin_ruja_stage` | plate | Ruja Ignatova photographed at a OneCoin event, full event photograph, landscape. Real archival image of her public persona on stage. | CC BY-SA 2.0 · Wikimedia Commons |  |
| `onecoin_ruse` | plate | The Danube bridge at Ruse, Bulgaria. Ignatova's birthplace (born 30 May 1980). | CC BY-SA 4.0 · NAC / Wikimedia Commons (CC BY-SA 4.0) |  |
| `onecoin_server_room` | plate | Data centre cooling and server cabinets, small landscape photo. Visual shorthand for the 'mining' that never existed. | CC BY-SA 4.0 · Da mocavi / Wikimedia Commons (CC BY-SA 4.0) |  |
| `onecoin_sofia` | plate | Panorama of central Sofia, National Archaeological Museum. OneCoin's home city. | CC BY 2.0 · Ann Wuyts from Olen (London), Belgium (United Kingdom) / Wikimedia Commons (CC BY 2.0) |  |
| `onecoin_vienna` | plate | Vienna skyline aerial panorama, CC0. Konstantin testified she held tickets to Vienna as well as Athens. | CC0 · Spicypepper999 / Wikimedia Commons (CC0) |  |
| `onecoin_wembley_interior` | plate | Generic large indoor arena bowl with tiered seating (Addition Financial Arena). Generic arena interior, do not caption as Wembley. | CC BY-SA 2.0 · elisfkc from Orlando, FL, United States / Wikimedia Commons (CC BY-SA 2.0) |  |
| `onecoin_wembley_night` | plate | Wembley Arena, London, illuminated at night, exterior. Where Ignatova headlined in June 2016. | CC BY-SA 2.0 · Robert Lamb / Wikimedia Commons (CC BY-SA 2.0) |  |
| `onecoin_westminster` | plate | Palace of Westminster, London, panoramic. UK regulators and Parliament form part of the warning trail. | CC BY-SA 2.5 · Diliff / Wikimedia Commons (CC BY-SA 2.5) |  |
| `onecoin_yacht` | plate | A superyacht at sea (Sailing Yacht A 'White Pearl'), portrait crop. Generic superyacht plate. | CC BY-SA 4.0 · KarleHorn & Waldi / Wikimedia Commons (CC BY-SA 4.0) |  |
| `onecoin_bitcoin_coins` | prop | Physical commemorative bitcoin tokens, square photo. The real thing OneCoin claimed it would kill. | CC BY-SA 3.0 · AntanaCoins / Wikimedia Commons (CC BY-SA 3.0) |  |
| `onecoin_doc_doj_greenwood` | prop | Screenshot: IRS/DOJ press release of 16 December 2022, 'Co-founder of multibillion-dollar cryptocurrency pyramid scheme OneCoin pleads guilty' (Greenwood). Shows the US Attorney quote and the €4.037 billion revenue figure. | Public domain (US federal government work) · U.S. Department of Justice / IRS-CI press release, 16 Dec 2022 (screenshot) |  |
| `onecoin_doc_fbi_wanted` | prop | Screenshot: FBI Ten Most Wanted Fugitives page for Ruja Ignatova, her photos, the official poster thumbnail and the five charges listed. | Public domain (US federal government work) · FBI Ten Most Wanted Fugitives page: Ruja Ignatova (screenshot, fbi.gov) |  |
| `onecoin_euro_cash` | prop | Euro banknotes, Europa series, flat presentation image. The scheme took cash in euros worldwide. | CC0 · Bericht / Wikimedia Commons (CC0) |  |
| `onecoin_gavel` | prop | A wooden judge's gavel, square studio photograph. | CC BY-SA 4.0 · Jonathunder / Wikimedia Commons (CC BY-SA 4.0) |  |
| `onecoin_gold_bars` | prop | Historic US National Archives photograph of a vault stacked with gold bars, public domain. | Public domain · Unknown authorUnknown author or not provided / Wikimedia Commons (Public domain) |  |
| `onecoin_hq_door` | prop | Close photograph of the OneCoin logo on the glass door of the Sofia office. Vertical frame. | CC BY-SA 3.0 · Ronny Martin Junnilainen / Wikimedia Commons (CC BY-SA 3.0) |  |
| `onecoin_ruja_fbi` | prop | FBI photograph of Ruja Ignatova (the bureau's own photo, landscape frame). The same image the FBI uses on her wanted page. | Public domain · FBI (via Wikimedia Commons) |  |

role: cut = cut-out (mid=/fg=) · plate = full background (bg=) · prop = object/document photo (fg=).
AI images are only plates/environments/props/textures — never real people, documents, logos or events.
